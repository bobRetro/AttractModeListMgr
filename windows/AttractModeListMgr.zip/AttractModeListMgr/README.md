# AttractModeMameListMgr
Purpopse
- Validate Mame entires using Mame's built-in validation feature

Requirements
- Need official version of Mame for validation, even if you are using Arcade64 in AttractMode
