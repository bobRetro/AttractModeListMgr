# AttractModeMameListMgr
Purpopse
- Validate Mame entires using Mame's built-in validation feature to eliminate non-working list entries
- Easily exclude unwanted clones/duplicates from lists
  - Adds “excluded” value to the “Extra” field for any unchecked entries to allow easy filtering in AttractMode
  - You'll need to add the "Extra not_contains excluded" rule to your display in AttractMode to utilize this feature after using AttraceModeListMgr

-	Maintain Favorites
- Configuration stored in separate file to retain settings if new list created.

Requirements
- Need official version of Mame executable for validation, even if you are using Arcade64 in AttractMode
